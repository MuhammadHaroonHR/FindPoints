import javax.swing.*;

public class EquationCalculator {

	public static void main(String[] args) {
//		JFrame frame = new JFrame("Quadratic formula");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//      //  frame.getContentPane().add(new quadaraticFormulaGuiPanel());
//        frame.pack();
//        frame.setResizable(true);
//        frame.setVisible(true);
		GUI G = new GUI();
        JFrame jframe = new JFrame("INTERNAL DIVISION POINT CALCULATOR");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.pack();
        jframe.setVisible(true);
        jframe.getContentPane().add(G);
        jframe.setResizable(false);
        jframe.pack();
        
       
        
      

        
		
	}

}
